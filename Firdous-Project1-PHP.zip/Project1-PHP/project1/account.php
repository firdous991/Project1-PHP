
    <?php
    session_start();
    if($_SESSION['login']==true){
        
        echo "<p> Welcome to your Bookstore! </p>";
    }
    else{
        header('index.php');
    }
	

?>