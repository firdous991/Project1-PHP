


<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title></title>
</head>

<style>
    p{
    text-align: center;
    font-size: 20px;
}

body{
 background-color:lightgoldenrodyellow;
}

 .container{
    position: relative;
text-align: center;
    font-family:arial,sans-serif;
    color:white;
   font-weight:bolder;}


.container .btn{position: absolute;
top:70%;
left: 50%;
transform: translate(-50%, -50%);
background-color: deepskyblue;
color: white;
font-size: 20px;
padding: 12ppx 24px;
border: none;
cursor: pointer;
border-radius: 5px;}
.container .btn:hover{background-color: black;}
#mysubmit{margin-left: 12em;}

.centered{position:absolute;
top:50%;
left:50%;
transform: translate(-50%, -50%);
font-size: 2.5em;}

.hero{width: 100%;
height: 40%;
position: relative;
}
h2{text-align:center;

padding-top:10px;

font-size: 2em;
color: #975102;

font-weight: bold;
font-family: sans-serif;
}
h3{font-size: 2em;
font-weight: bolder;
color: #975102;
text-align: center;}



footer{background-color: black;
padding-bottom: 10px;
padding-top: 10px;
border-top: solid 2px black;
color: skyblue;
font-size: .9em;
font-style: italic;
text-align: center;
margin: auto
}

    .topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color:#4CAF50;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
    h1{font-size: 2em;
    font-family:cursive;
line-height: 1.7em;
text-indent:5%;
background-image:url(log1.png);
    background-repeat: no-repeat;
    background-position:left 6px;
    
}
     .bookList{
        text-align: center;
        font-size: 20px;
         padding: 5px 10px;
background-color: white;
border: 1px solid black;
margin-left: 10em;
margin-right: 10em;
margin-top: 1em;

    }
    table,th{margin: 10px;
    
    } 
    #tabl{margin-left: 22em;
margin-right: 18em;}
    
     header,h1{margin-top: 0;
        
        
    }
</style>



    
    
    <header>
        
            <h1>Book Store</h1>
</header>



<div class="topnav">
  <a href="index.php">Home</a>
    <a href="about.html">About</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
  
</div>
<body>

    

<div class="hero">

    <div class="container">
        <img src="https://thewritelife.com/wp-content/uploads/2019/08/How-to-format-a-book.jpg" width="100%" height="350">
     
    <div class="centered">Latest Books</div>
<button class="btn">Contact Us</button>
        </div>
</div>
    
<h2> Top Books list</h2>
    <div class="bookList">
    <div id="tabl">
  <table border="1"  >
    <thead>
      <tr>
        <th>Book Title</th>
        <th>Price</th>
        <th>Description</th>
      </tr>
    </thead>
    </table>
        </div>
    <?php 
    
require('mysqli_connect.php');
        
       
$q= "select * from books";
$r= mysqli_query($dbc,$q);
while($row = mysqli_fetch_assoc($r)){
    $cmt=$row['book_title'];
    $cmt1=$row['price'];
    $cmt2=$row['description'];
        
    
echo '<a href="checkout.html">Click here</a>';


    echo '&nbsp'.'&nbsp'.$cmt. '&nbsp'.'&nbsp'.$cmt1. '&nbsp'.'&nbsp' .$cmt2.
        '</br>'. '</br>';
  };
        
        
    ?>   
    </div>
    
<br>
<br>
</body>
<footer>
    <small>
        <i>
        copyright &copy;2020 BooksStore<br>
            <a href="mailto:firdous.fatima991@gmail.com">firdous.fatima991@gmail.com</a></i>
        
        </small>
    </footer>
</html>
    