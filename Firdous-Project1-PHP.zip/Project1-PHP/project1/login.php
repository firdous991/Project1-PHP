<?php

require('./mysqli_connect.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($dbc,$_REQUEST['username']);
    $password = mysqli_real_escape_string($dbc,$_REQUEST['password']);
    
    $q = "select * from users " ;
    $r =@mysqli_query($dbc,$q) or
        die($mysqli_error($dbc));
    
    
    session_start();
    if(mysqli_num_rows($r)){

    $_SESSION['login']=true;
        
        header('Location:account.php');
    }
		

	 else { 
    echo '<p> Invalid login information </p>';
	}

	mysqli_close($dbc); // Close the database connection.
 // End of the main submit conditional.
}
?>
